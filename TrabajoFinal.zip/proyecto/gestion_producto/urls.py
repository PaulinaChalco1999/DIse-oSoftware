from django.contrib import admin
from django.urls import path
from django.urls.conf import include
from .views import *

urlpatterns = [
    path('',index, name='index'),
    path('add_producto', add_producto, name='add_producto'),
    path('edit_producto/<int:myid>/', edit_producto, name='edit_producto'),
    path('delete_producto/<int:myid>/', delete_producto, name='delete_producto'),
    path('update_producto/<int:myid>/', update_producto, name='update_producto'),
]