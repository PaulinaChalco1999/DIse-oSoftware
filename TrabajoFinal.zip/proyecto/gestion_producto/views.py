from django.shortcuts import redirect, render, HttpResponse
from django.http import HttpRequest
from .models import Productos
from django.contrib import messages
# Create your views here.

def index(request):
    item_list = Productos.objects.all()
    context = {
        'item_list' : item_list
    }

    return render(request,'index.html', context)
    
def add_producto(request):
    if request.method == 'POST':
        nombre = request.POST['nombre']
        marca = request.POST['marca']
        precio = request.POST['precio']
        stock = request.POST['stock']
        tipo = request.POST['tipo']
        productos = Productos(nombre = nombre, marca = marca, precio = precio, stock = stock, tipo = tipo)
        productos.save()
        messages.info(request, "El producto se añadio correctamente")
    else:
        messages.info(request, "El productos no se pudo añadir")

    item_list = Productos.objects.all()
    context = {
        'item_list' : item_list
    }

    return render(request,'index.html', context)

def delete_producto(request, myid):
    producto = Productos.objects.get(id=myid)
    producto.delete()
    messages.info(request, "El producto ha sido eliminado correctamente")
    return redirect(index)

def edit_producto(request, myid):
    sel_producto = Productos.objects.get(id=myid)
    item_list = Productos.objects.all()
    context = {
        'sel_producto' : sel_producto,
        'item_list' : item_list
    }
    return render(request,'index.html', context)

def update_producto(request, myid):
    producto = Productos.objects.get(id=myid)
    producto.nombre = request.POST['nombre']
    producto.marca = request.POST['marca']
    producto.precio = request.POST['precio']
    producto.stock = request.POST['stock']
    producto.tipo = request.POST['tipo']
    producto.save()
    messages.info(request, "El producto ha sido actualizado correctamente")
    return redirect('index')