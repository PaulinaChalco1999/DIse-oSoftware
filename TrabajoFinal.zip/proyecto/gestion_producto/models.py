from django.db import models

# Create your models here.
class Productos(models.Model):
    nombre = models.CharField(max_length=255, null=False)
    marca = models.CharField(max_length=255, null=False)
    precio = models.CharField(max_length=255, null=False)
    stock = models.CharField(max_length=255, null=False)
    tipo = models.CharField(max_length=255, null=False)



